<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ActivityController;
use App\Http\Controllers\ActividadController;
use App\Http\Controllers\UserAccessController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\tasks\GruposController;
use App\Http\Controllers\tasks\ListasController;
use App\Http\Controllers\tasks\TareasController;
use App\Http\Controllers\RolePermissionController;
use App\Http\Controllers\tasks\EtiquetasController;
use App\Http\Controllers\tasks\ChecklistsController;
use App\Http\Controllers\tasks\ComentariosController;
use App\Http\Controllers\tasks\TareaAdjuntosController;
use App\Http\Controllers\documents\DocumentosController;
use App\Http\Controllers\Configuration\SucusaleController;
use App\Http\Controllers\Configuration\WarehouseController;
use App\Http\Controllers\Configuration\ClientSegmentController;
use App\Http\Controllers\Configuration\MethodPaymentController;
use App\Http\Controllers\Configuration\SucursaleDeliverieController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group([
 
    // 'middleware' => 'auth:api',
    'prefix' => 'auth',
//    'middleware' => ['auth:api'],//,'permission:publish articles|edit articles'
], function ($router) {
    Route::post('/register', [AuthController::class, 'register'])->name('register');
    Route::post('/login', [AuthController::class, 'login'])->name('login');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::post('/refresh', [AuthController::class, 'refresh'])->name('refresh');
    Route::post('/me', [AuthController::class, 'me'])->name('me');
});

Route::group([
    'middleware' => 'auth:api',
], function ($router) {
    Route::resource("roles",RolePermissionController::class); 

    Route::get('/users/search', [GruposController::class, 'searchUsers']);      

    Route::post('/users/{id}', [UserAccessController::class, 'update']);
    Route::get("users/config", [UserAccessController::class, 'config']);
    Route::resource("users",UserAccessController::class); 

    // Route::resource('task');

    Route::resource("sucursales",SucusaleController::class); 
    Route::resource("warehouses",WarehouseController::class); 
    Route::resource("sucursale_deliveries",SucursaleDeliverieController::class); 
    Route::resource("method_payments",MethodPaymentController::class); 
    Route::resource("client_segments",ClientSegmentController::class); 

    // Route::post('/tareas/{id}', [TareasController::class, 'update']);
    Route::get("tareas/config",[TareasController::class, 'config']);
    Route::post('/tareas/{id}/move', [TareasController::class, 'move']);
    Route::resource("tareas",TareasController::class);

    Route::get('/tareas/{tareaId}/timeline', [ComentariosController::class, 'index']);
    Route::post('/tareas/{tareaId}/comentarios', [ComentariosController::class, 'store']);
    Route::put('/tareas/{tareaId}/comentarios/{comentarioId}', [ComentariosController::class, 'update']);
    Route::delete('/tareas/{tareaId}/comentarios/{comentarioId}', [ComentariosController::class, 'destroy']);

    Route::post('/grupos/{id}/toggle-star', [GruposController::class, 'toggleStar']);
    Route::post('/grupos/{id}/share', [GruposController::class, 'share']);
    Route::delete('/grupos/{grupoId}/unshare/{userId}', [GruposController::class, 'unshare']);
    // Agregar esta ruta en api.php dentro del grupo con middleware auth:api
    Route::get('/grupos/{id}/shared-users', [GruposController::class, 'getSharedUsers']);
    Route::resource("grupos", GruposController::class);

    // ========== RUTAS PARA DOCUMENTOS ==========
    // Route::get("documentos/config",[DocumentosController::class, 'config']);
    // Route::resource("documentos",DocumentosController::class);
    Route::get('/documentos', [DocumentosController::class, 'index']);
    Route::post('/documentos', [DocumentosController::class, 'store']);
    Route::get('/documentos/config', [DocumentosController::class, 'config']);
    Route::put('/documentos/{id}', [DocumentosController::class, 'update']);
    Route::delete('/documentos/{id}', [DocumentosController::class, 'destroy']);

    // ========== RUTAS PARA CARPETAS ==========
    Route::get('/documentos/tree', [DocumentosController::class, 'getTree']);
    Route::post('/documentos/folder', [DocumentosController::class, 'createFolder']);
    Route::get('/documentos/folder/{id}', [DocumentosController::class, 'getFolderContents']);
    Route::post('/documentos/{id}/move', [DocumentosController::class, 'move']);

    // ========== NUEVAS RUTAS PARA DESCARGA Y VISUALIZACIÓN ==========
    Route::get('/documentos/{id}/download', [DocumentosController::class, 'download']);
    Route::get('/documentos/{id}/info', [DocumentosController::class, 'getDocumentInfo']);

    Route::post('listas/reorder', [ListasController::class, 'reorder']);
    Route::apiResource('listas',ListasController::class);

    // Rutas de permisos de grupos (solo para propietarios)
    Route::get('/grupos/{id}/permissions', [GruposController::class, 'getPermissions']);
    Route::post('/grupos/{id}/permissions/type', [GruposController::class, 'updatePermissionType']);
    Route::post('/grupos/{grupoId}/permissions/user/{userId}', [GruposController::class, 'updateUserPermission']);
    Route::post('/grupos/{id}/permissions/batch', [GruposController::class, 'updateBatchPermissions']);
    Route::get('/grupos/{id}/check-write-access', [GruposController::class, 'checkWriteAccess']);
    
    // Etiquetas
    Route::get('/tareas/{tareaId}/etiquetas', [EtiquetasController::class, 'index']);
    Route::post('/tareas/{tareaId}/etiquetas', [EtiquetasController::class, 'store']);
    Route::put('/tareas/{tareaId}/etiquetas/{etiquetaId}', [EtiquetasController::class, 'update']);
    Route::delete('/tareas/{tareaId}/etiquetas/{etiquetaId}', [EtiquetasController::class, 'destroy']);

    // Checklists
    Route::get('/tareas/{tareaId}/checklists', [ChecklistsController::class, 'index']);
    Route::post('/tareas/{tareaId}/checklists', [ChecklistsController::class, 'store']);
    Route::put('/tareas/{tareaId}/checklists/{checklistId}', [ChecklistsController::class, 'update']);
    Route::delete('/tareas/{tareaId}/checklists/{checklistId}', [ChecklistsController::class, 'destroy']);

    // Checklist Items
    Route::post('/tareas/{tareaId}/checklists/{checklistId}/items', [ChecklistsController::class, 'addItem']);
    Route::put('/tareas/{tareaId}/checklists/{checklistId}/items/{itemId}', [ChecklistsController::class, 'updateItem']);
    Route::delete('/tareas/{tareaId}/checklists/{checklistId}/items/{itemId}', [ChecklistsController::class, 'destroyItem']);

    // Adjuntos de tareas
    Route::get('/tareas/{tareaId}/adjuntos', [TareaAdjuntosController::class, 'index']);
    Route::post('/tareas/{tareaId}/adjuntos', [TareaAdjuntosController::class, 'store']);
    Route::delete('/tareas/{tareaId}/adjuntos/{adjuntoId}', [TareaAdjuntosController::class, 'destroy']);

    // Rutas de miembros de tareas
    Route::post('/tareas/{tarea}/assign-members', [TareasController::class, 'assignMembers']);
    Route::get('/tareas/{tarea}/members', [TareasController::class, 'getMembers']);
    Route::delete('/tareas/{tarea}/unassign-member/{user}', [TareasController::class, 'unassignMember']);

    // ========================================
    // RUTAS DE ACTIVIDADES
    // ========================================
    Route::get('/activities', [ActivityController::class, 'index']);
    Route::get('/activities/tarea/{tareaId}', [ActivityController::class, 'getByTarea']);
    Route::post('/activities', [ActivityController::class, 'store']);
    Route::delete('/activities/{id}', [ActivityController::class, 'destroy']);
    
    
    // ========================================
    // RUTAS DE NOTIFICACIONES
    // ========================================
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::get('/notifications/unread-count', [NotificationController::class, 'getUnreadCount']);
    Route::put('/notifications/{id}/read', [NotificationController::class, 'markAsRead']);
    Route::put('/notifications/read-all', [NotificationController::class, 'markAllAsRead']);
    Route::delete('/notifications/{id}', [NotificationController::class, 'destroy']);
    Route::delete('/notifications/delete-read', [NotificationController::class, 'deleteAllRead']);
    
    // 🆕 NUEVA RUTA PARA DEBUGGING
    Route::get('/notifications/debug', [NotificationController::class, 'debug']);

    // ========================================
    // RUTAS DE PERFIL (Protegidas con JWT)
    // ========================================
    Route::get('/profile/tareas', [ProfileController::class, 'getUserTareas']);
    Route::get('/profile/documentos', [ProfileController::class, 'getUserDocumentos']);
    Route::get('/profile/stats', [ProfileController::class, 'getUserStats']);
    
    // ✅ NUEVO: Endpoint optimizado que devuelve todo en una sola llamada
    Route::get('/profile/complete', [ProfileController::class, 'getCompleteProfile']);

});

// porque OnlyOffice necesita acceder sin token
Route::post('/documentos/{id}/save-callback', [DocumentosController::class, 'saveDocument']);